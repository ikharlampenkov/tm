

/**
 * class TM_Document_Document
 * 
 */
class TM_Document_Document
{

    /** Aggregations: */

    /** Compositions: */

     /*** Attributes: ***/






} // end of TM_Document_Document
?>
