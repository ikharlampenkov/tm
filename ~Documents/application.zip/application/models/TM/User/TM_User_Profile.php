<?php

/**
 * class TM_User_Profile
 * 
 */
class TM_User_Profile
{

    /** Aggregations: */

    /** Compositions: */

     /*** Attributes: ***/






} // end of TM_User_Profile
?>
